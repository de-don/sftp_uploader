#!/usr/bin/env bash
flameshot gui -r  | path/to/sftp_uploader -r
